import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/*
 *  SequentialAnalysis is a tiny tool to analyze a single hour's worth of data from
 *  the logs and find out the most popular english wikipedia articles. The analysis
 *  is based on 5 rules defined on Writeup.
 *  
 *  Test has been made on Amazon EC2 t1.micro instance using the AMI ID: ami-ed30ba84
 *  for s3://wikipediatraf/201407-gz/pagecounts-20140701-000000.gz file.
 *
 *  @Author: Kailiang Chen(kailianc)
 *  @Version: 1.0
 *  @Date: 09/06/2014
 *  
 */

public class SequentialAnalysis {
    /*
     * Rule 2 : Definition of TOPICS to be filtered out
    */
    private static final String[] TOPICS = {
        "Media:", "Special:", "Talk:", "User:", "User_talk:", "Project:", 
        "Project_talk:", "File:", "File_talk:", "MediaWiki:", "MediaWiki_talk:", 
        "Template:", "Template_talk:", "Help:", "Help_talk:", "Category:", 
        "Category_talk:", "Portal:", "Wikipedia:", "Wikipedia_talk:"
        };
        
    /*
     * Rule 4 : Definition of file EXTENSIONS to be filtered out
     */
    private static final String[] EXTENSIONS = {
        ".jpg", ".gif", ".png", ".JPG", ".GIF", ".PNG", ".txt", ".ico",
        };
	
    /*
     * Rule 5 : Definition of BOILERPLATE articles to be filtered out
     */
    private static final String[] BOILERPLATE = {
        "404_error/", "Main_Page", "Hypertext_Transfer_Protocol", "Favicon.ico", "Search"
        };
	
    private static final int CONTENT_ITEM_NUM = 4;
    private static final int EXTENSION_LENGTH = 4;
    private static final int PRINT_PER_LINENUM = 100000;
    
    public static void main(String[] args) {   	
        long startTime = System.currentTimeMillis();
        try {
            FileReader fr = new FileReader(args[0]);
            BufferedReader br = new BufferedReader(fr);  
            
            String line = null, topArticle = null;
            long lineNumAll = 0, lineNumEn = 0, lineNumTpc = 0, 
                 lineNumChr = 0, lineNumExt = 0, lineNumBpt = 0, accessSum = 0;
            
            HashMap<String, Integer> map = new HashMap<String, Integer>();
            
            System.out.print("filtering");
            while (br.ready()) {
                line = br.readLine();                
                if(line == null || line.isEmpty()) {
                    System.out.print("-");
                    continue;
                }
            	
                lineNumAll++;
                if(lineNumAll % PRINT_PER_LINENUM == 0) {
                    System.out.print(".");
                }
                
                String[] strAry = line.split(" ");
                String prjName = strAry[0];
                String pgTitle = strAry[1];
                Integer numAccess = 0;
                
                try {  
                    numAccess = Integer.valueOf(strAry[2]);
                    accessSum += numAccess;					
                } catch(NumberFormatException e) {
                    e.printStackTrace();
                    continue;
                }
                
                if (strAry.length > CONTENT_ITEM_NUM) {
                    System.out.println("Format error!");
                    System.out.println("No." + lineNumAll + " " + line);
                    continue;
                }
                
                /*
                 * Rule 1 : Project Name which does not start with "en"
                 * (no suffix) is to be filtered out
                 */
                if(!prjName.equals("en")) {
                    lineNumEn++;
                    continue;
                }
                
                /*
                 * Rule 2 : Page Title which starts with TOPICS is to be filtered out
                 */
                boolean isTopicErr = false;
                for(String str : TOPICS) {
                    if(pgTitle.startsWith(str)) {
                        isTopicErr = true;
                        break;
                    }
                }                
                if(isTopicErr) {
                    lineNumTpc++;
                    continue;
                }
                
                /*
                 * Rule 3 : Page Title which starts with lowercase English 
                 * characters is to be filtered out
                 */
                char firstChar = pgTitle.charAt(0); 
                if(firstChar >= 'a' && firstChar <= 'z') {
                    lineNumChr++;
                    continue;
                }
                
                /*
                 * Rule 4 : Page Title which ends with EXTENSIONS is to be filtered out
                 */
                int len = pgTitle.length();
                if(len >= EXTENSION_LENGTH) {
                    boolean isExtErr = false;
	            String s = pgTitle.substring(len - EXTENSION_LENGTH, len);
		    for(String str : EXTENSIONS) {
		        if(s.equals(str)) {
		            isExtErr = true;
		            break;
		        }
		    }                
		    if(isExtErr) {
		        lineNumExt++;
		        continue;
		    }
	        }
                
                /*
                 * Rule 5 : Page Title which exactly matches BOILERPLATE 
                 * is to be filtered out
                 */
                boolean isBptErr = false;
	        for(String str : BOILERPLATE) {
	            if(pgTitle.equals(str)) {
	                isBptErr = true;
	                break;
	            }
	        }                
	        if(isBptErr) {
	            lineNumBpt++;
	            continue;
	        }
                
	        // Put filtered result to a map in (Page Title -> Num of Access) style 
	        map.put(pgTitle, numAccess);
            }
            br.close();
            fr.close();
            
            // Delete old result file 
            File f = new File(args[0] + "_result");
            if(f.exists()) {
            	f.delete();
            }
            
            FileWriter fw = new FileWriter(args[0] + "_result");
            BufferedWriter bw = new BufferedWriter(fw);
            
            ValueComparator vc =  new ValueComparator(map);
            TreeMap<String, Integer> sortedMap = new TreeMap<String, Integer>(vc);
            sortedMap.putAll(map);
            
            // Output the new result to file in Descending Order of Num_of_Access
            int lineNumRst = 0;
            for(Map.Entry<String, Integer> entry : sortedMap.entrySet()) {
                String key = entry.getKey();
        	Integer value = entry.getValue();
                
        	bw.write(value + "\t" + key);
        	bw.newLine();  
		
                if(lineNumRst == 0) {
		    topArticle = value + " " + key;
		}
			
        	lineNumRst++;
            } 
            bw.flush();    
            bw.close();
            fw.close();
            
            System.out.print("finished\n");
            
            // Print out the statistical result
	    System.out.println("The most popular article is " + topArticle);
            System.out.println("lineNumAll = " + lineNumAll);
            System.out.println("lineNumRst = " + lineNumRst);
            System.out.println("lineNumEn = " + lineNumEn);
            System.out.println("lineNumChr = " + lineNumChr);
            System.out.println("lineNumTpc = " + lineNumTpc);
            System.out.println("lineNumExt = " + lineNumExt);
            System.out.println("lineNumBpt = " + lineNumBpt);			
			System.out.println("accessSum = " + accessSum);			
			
            if(lineNumAll != (lineNumRst + lineNumEn + lineNumTpc 
                + lineNumChr + lineNumExt + lineNumBpt)) {
                System.out.println("Line Number Error!");
            }
        } catch(IOException e) {
            e.printStackTrace();
        }
        long estimatedTime = System.currentTimeMillis() - startTime;
        System.out.println(estimatedTime + "msec");
    }
}

/*
 * Comparator to support Sort by Value in Descending Order used in Treemap
 * 
 */
class ValueComparator implements Comparator<String> {
    Map<String, Integer> base;
    public ValueComparator(Map<String, Integer> base) {
        this.base = base;
    }

    public int compare(String a, String b) {
        if (base.get(a) >= base.get(b)) {
            return -1;
        } else {
            return 1;
        } 
    }
}
