#!/bin/bash

export COMPILE_COMMAND="javac SequentialAnalysis.java"
export EXECUTE_COMMAND="java -Xmx512m SequentialAnalysis pagecounts-20140701-000000"

eval $COMPILE_COMMAND
eval $EXECUTE_COMMAND

