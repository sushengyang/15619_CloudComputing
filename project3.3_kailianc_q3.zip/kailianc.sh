#! /bin/bash

# get the result
query_first=$(mysql -e "show status like 'Queries';" | egrep -o "[0-9]*")
query_second=$query_first

# run 3000 minutes
for (( i=0; i<3000; i++ ))
do 
    query_first=$(mysql -e "show status like 'Queries';" | egrep -o "[0-9]*")
    q_inter=$[query_first-query_second-3]
    tps=$(echo "scale=5; $q_inter / 133113" | bc)
    mon-put-data --namespace="MySite" --metric-name=tps --unit=Count/Second --value=$tps
    query_second=$query_first
    # wait 1 miniute
    sleep 60 
done

