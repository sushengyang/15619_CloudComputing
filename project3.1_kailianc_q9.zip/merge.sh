#!/bin/bash
join -t , -1 1 -2 1 million_songs_sales_data.csv million_songs_metadata.csv > merge.csv
cut -d "," -f 3,7 merge.csv > cut.csv
awk -F, '{ a[$2]+=$1 } END{ for(val in a) printf("%s %s\n", val, a[val]) }' <(tail -n +2 cut.csv) | sort -k 2 -n > result.csv
artist_id=`tail -1 result.csv | cut -d ' ' -f 1`
awk -v artist_id=$artist_id 'BEGIN {FS = ","} ; { if( $5 == artist_id) { print $7; }}' million_songs_metadata.csv | head -1

