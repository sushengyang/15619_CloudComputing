#!/bin/bash
_artist_name=$1
_start_year=$2
_end_year=$3
IFS=","
count=0
num=0
cat million_songs_metadata.csv | while read -r track_id title song_id release artist_id \
    artist_mbid artist_name duration artist_familiarity \
    artist_hotttnesss year
do
    if [[ ${artist_name,,} == *"${_artist_name,,}"* ]];
    then
        if [ $_start_year -le $year ] && [ $_end_year -gt $year ];
        then
            count=$(($count+1));
            echo $count
        fi
    fi
done 
echo 'done'

