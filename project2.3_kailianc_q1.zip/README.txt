Scenario/Functionality:

Step 1. Read Credentials
Step 2. Create Elastic Load Balancer
Step 3. Configure Health Check
Step 4. Create Load Configuration
Step 5. Create Auto Scale Group
Step 6. Create a SNS notification(register to email)
Step 7. Create Auto Scale Out Policy
Step 8. Create Auto Scale In Policy
Step 9. Create Cloud Watch for Scale Out
Step 10. Create Cloud Watch for Scale In
Step 11. Create Load Generator
Step 12. Activate Load Generator
Step 13. Warm up 
Step 14. Launch test
Step 15. Terminate instances and delete configuration(if user inputs 'y')