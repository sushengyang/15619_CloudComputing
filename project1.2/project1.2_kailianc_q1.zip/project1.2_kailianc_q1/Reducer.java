import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;


public class Reducer {
	private static final int LIMIT = 100000;
	
    public static void main(String[] args) {
    	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    	HashMap<String, Integer> map = new HashMap<String, Integer>();
    	String line = null;
    	String currentTitle = null;
    	Integer totalAccess = 0;
    	
		try {
			while((line = br.readLine()) != null) {
				if(line == "") {
					continue;
				}
				try {
					String[] parts = line.split("\t");
					String title = parts[0];
					String[] info = parts[1].split("-");
					String date = info[0];
					int access = Integer.parseInt(info[1]);
					
					if(!title.equals(currentTitle)) {
						if(currentTitle != null && totalAccess > LIMIT) {
							StringBuilder str = new StringBuilder();
							for(Map.Entry<String, Integer> entry : map.entrySet()) {
								String key = entry.getKey();
				        	    Integer value = entry.getValue();
								str.append("\t" + key + ":" + value);
							}
							System.out.println(totalAccess + "\t" + currentTitle + str.toString());
						}
						currentTitle = title;
						totalAccess = access;
						map.clear();
						map.put(date, access);
					} else {
						currentTitle = title;
						totalAccess += access;
						
						Integer currentAccess = map.get(date);
						if(currentAccess != null) {
							currentAccess += access;
							map.put(date, currentAccess);
						} else {
							map.put(date, access);
						}						
					}					
				} catch (NumberFormatException e) {
					continue;
				}
			}
			
			if(currentTitle != null && totalAccess > LIMIT) {
				StringBuilder str = new StringBuilder();
				for(Map.Entry<String, Integer> entry : map.entrySet()) {
					String key = entry.getKey();
	        	    Integer value = entry.getValue();
					str.append("\t" + key + ":" + value);
				}
				System.out.println(totalAccess + "\t" + currentTitle + str.toString());
			}			
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
}
