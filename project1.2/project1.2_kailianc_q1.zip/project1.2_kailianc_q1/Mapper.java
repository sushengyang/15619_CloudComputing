import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class Mapper {
	/*
	 * Rule 1 : Definition of LANGUAGE
	 */
	private static final String LANGUAGE = "en";
	
	/*
	 * Rule 2 : Definition of TOPICS
	 */
    private static final String[] TOPICS = {
        "Media:", "Special:", "Talk:", "User:", "User_talk:", "Project:", "Project_talk:", 
        "File:", "File_talk:", "MediaWiki:", "MediaWiki_talk:", "Template:", "Template_talk:",
        "Help:", "Help_talk:", "Category:", "Category_talk:", "Portal:", "Wikipedia:", 
        "Wikipedia_talk:",
        };
    
    /*
	 * Rule 3 : Definition of PREFIX
	 */
    private static final String PREFIX = "abcdefghijklmnopqrstuvwxyz";
        
    /*
     * Rule 4 : Definition of file EXTENSIONS
     */
    private static final String[] EXTENSIONS = {
        ".jpg", ".gif", ".png", ".JPG", ".GIF", ".PNG", ".txt", ".ico",
        };
    
    /*
     * Rule 5 : Definition of BOILERPLATE articles
     */
    private static final String[] BOILERPLATE = {
        "404_error/", "Main_Page", "Hypertext_Transfer_Protocol", "Favicon.ico", "Search", 
        };
    
    private static final int EXTENSION_LENGTH = 4;

	
	public static void main(String[] args) {
		String env = System.getenv("map_input_file");
		
		int pos = -1;
		if(env != null) {
			if(env.contains("/")) {
				pos = env.lastIndexOf("/");
				if(pos != -1) {
					env = env.substring(pos + 1, env.length());
				}	
			}		
			
			if(env.contains(".")) {
				pos = env.lastIndexOf(".");
				if(pos != -1) {
					env = env.substring(0, pos);
				}
			}
		}
		
		String date = null;
		if(env != null) {
			String[] parts = env.split("-");
			date = parts[1];
		}
		
	    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	    String line = null;
	    try {
			while((line = br.readLine()) != null) {
				if(line == "") {
					continue;
				}				
				String[] parts = line.split(" ");
                String project = parts[0];
                String title = parts[1];
                String accesshour = parts[2];
                
                if(!isMatched(project, title)) {
                    System.out.println(title + "\t" + date + "-" + accesshour);
                }
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private static boolean isMatched(String project, String title) {
		 /*
         * Rule 1 : Project Name which does not start with "en"(no suffix) is to be filtered out
         */
        if(!project.startswith(LANGUAGE)) {
        	return true;
        }
        
        /*
         * Rule 2 : Page Title which starts with TOPICS is to be filtered out
         */
        for(String str : TOPICS) {
            if(title.startsWith(str)) {
                return true;           
            }
        }
        
        /*
         * Rule 3 : Page Title which starts with lowercase English characters is to be filtered out
         */
        String firstChar = title.substring(0, 1);
        if(PREFIX.contains(firstChar)) {
            return true;
        }
        
        /*
         * Rule 4 : Page Title which ends with EXTENSIONS is to be filtered out
         */
        int len = title.length();
        if(len >= EXTENSION_LENGTH) {
            String s = title.substring(len - EXTENSION_LENGTH, len);
            for(String str : EXTENSIONS) {
                if(s.equals(str)) {
                    return true;
                }
            }
        }
        
        /*
         * Rule 5 : Page Title which exactly matches BOILERPLATE is to be filtered out
         */
        for(String str : BOILERPLATE) {
            if(title.equals(str)) {
                return true;
            }
        }
        
        return false;
	}
}
