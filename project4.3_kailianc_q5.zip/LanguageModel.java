import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class LanguageModel {

	public static class Map extends Mapper<LongWritable, Text, Text, Text> {
		public void map(LongWritable key, Text value, Context context)
				throws IOException, InterruptedException {
			String line = value.toString();
			if (line == null || line.length() == 0)
				return;

			String[] parts = line.split("\t");
			String phrase = parts[0];
			int count = Integer.parseInt(parts[1]);
			if (count <= 1) {
				return;
			}

			if (phrase.contains(" ")) {
				parts = phrase.split(" ");
				if (parts.length <= 1) {
					return;
				}
			} else {
				return;
			}

			int pos = phrase.lastIndexOf(" ");
			String prefix = line.substring(0, pos);
			String word = phrase.substring(pos) + count;
			
			Text outputPref = new Text();
			Text outputWord = new Text();
			outputPref.set(prefix);
			outputWord.set(word);

			context.write(outputPref, outputWord);
		}
	}

	public static class Reduce extends Reducer<Text, Text, Text, Text> {
		private static final int RANK = 5;
		
		public void reduce(Text key, Iterable<Text> values, Context context)
				throws IOException, InterruptedException {
			HashMap<String, Integer> map = new HashMap<String, Integer>();
			int sum = 0;
			for (Text value : values) {
				String str = value.toString();
				int pos = str.lastIndexOf(" ");
				String word = str.substring(0, pos);
				int count = Integer.parseInt(str.substring(pos));
				sum += count;
				map.put(word, count);
			}

			List<Entry<String, Integer>> list = new ArrayList<Entry<String, Integer>>(
					map.entrySet());
			Collections.sort(list, new Comparator<Entry<String, Integer>>() {
				public int compare(Entry<String, Integer> e1,
						Entry<String, Integer> e2) {
					return ((Integer) e2.getValue() - (Integer) e1.getValue());
				}
			});

			int limit = (list.size() > RANK) ? RANK : list.size();
			StringBuilder sb = new StringBuilder();
			for(int i = 0; i < limit; i++) {
				String next = list.get(i).getKey();
				int count = list.get(i).getValue();
				double prob = (double) count * 100.0 / (double) sum;
				sb.append(next).append(prob);
			}
			Text outputValue = new Text();
			outputValue.set(sb.toString());
			context.write(key, outputValue);
		}
	}

	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();

		conf.set("mapred.compress.map.output", "true");
		conf.set("mapred.output.compression.type", "BLOCK");
		conf.set("mapred.map.output.compression.codec",
				"org.apache.hadoop.io.compress.GzipCodec");

		Job job = new Job(conf, "languagemodel");
		job.setJarByClass(LanguageModel.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

		job.setMapperClass(Map.class);
		job.setCombinerClass(Reduce.class);
		job.setReducerClass(Reduce.class);

		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);

		job.setNumReduceTasks(1);

		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));

		job.waitForCompletion(true);
	}

}