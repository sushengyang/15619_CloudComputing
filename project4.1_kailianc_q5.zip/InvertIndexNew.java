import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashSet;
import java.util.Set;
import java.util.StringTokenizer;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.filecache.DistributedCache;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapred.JobConf;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.FileSplit;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;

public class InvertIndexNew extends Configured implements Tool {

	static Set<String> set = new HashSet<String>();

	public static class Map extends Mapper<LongWritable, Text, Text, Text> {
		private Text word = new Text();
		private Text location = new Text();

		public void map(LongWritable key, Text value, Context context)
				throws IOException, InterruptedException {
			FileSplit fs = (FileSplit) context.getInputSplit();
			String filename = fs.getPath().getName();

			location.set(filename);
			String line = value.toString();
			char[] ch = line.toCharArray();
			StringBuffer s = new StringBuffer();
			for (char c : ch) {
				if (!Character.isLetterOrDigit(c)) {
					c = ' ';
				}
				s.append(c);
			}

			line = s.toString();
			line = line.trim();

			StringTokenizer tokenizer = new StringTokenizer(line.toLowerCase());
			while (tokenizer.hasMoreTokens()) {
				String tmp = tokenizer.nextToken();
				if (!set.contains(tmp)) {
					word.set(tmp);
					context.write(word, location);
				}
			}
		}
	}

	public static class Reduce extends Reducer<Text, Text, Text, Text> {
		public void reduce(Text key, Iterable<Text> values, Context context)
				throws IOException, InterruptedException {
			boolean first = true;
			String results = "";
			String tmp = "";
			for (Text val : values) {
				if (!first)
					results += " ";
				first = false;
				tmp = val.toString();
				if (results.contains(tmp) == false) {
					results += tmp;
				}
			}
			context.write(key, new Text(results));
		}
	}

	public static void main(String[] args) throws Exception {
		int res = ToolRunner.run(new Configuration(), new InvertIndexNew(), args);
		System.exit(res);
	}
	
	public void configure(JobConf job) {
		if (job.getBoolean("wordcount.skip.patterns", false)) {
			Path[] patternsFiles = new Path[0];
		    try {
		        patternsFiles = DistributedCache.getLocalCacheFiles(job);
		    } catch (IOException ioe) {
		    }
		    for (Path patternsFile : patternsFiles) {
		    	try {
		    		BufferedReader fis = new BufferedReader(new FileReader(patternsFile.toString()));
	
					String line;
					while ((line = fis.readLine()) != null) {
						String newstr = new String(line.getBytes(), "UTF-8");
						set.add(newstr);
					}
					System.out.println(set);
				} catch (IOException e) {
				}
		    }
		}
	}

	@Override
	public int run(String[] args) throws Exception {
//		URI uri = null;
		Configuration conf = new Configuration();
		
		conf.set("mapred.compress.map.output", "true");
	    conf.set("mapred.output.compression.type", "BLOCK"); 
	    conf.set("mapred.map.output.compression.codec", "org.apache.hadoop.io.compress.GzipCodec"); 
		
		for (int i=0; i < args.length; ++i) {
			if ("-skip".equals(args[i])) {
//				uri = new Path(args[++i]).toUri();
				DistributedCache.addCacheFile(new Path(args[++i]).toUri(), conf);
				conf.setBoolean("wordcount.skip.patterns", true);
			}
		}
		
		Job job = new Job(conf, "InvertIndexNew");
		job.setJarByClass(InvertIndexNew.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);

		job.setMapperClass(Map.class);
		job.setCombinerClass(Reduce.class);
		job.setReducerClass(Reduce.class);

		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);

		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));

		job.waitForCompletion(true);
		return 0;
	}
}